import { CalendarView } from './calendar-view.model';

describe('CalendarView', () => {
  it('should create an instance', () => {
    expect(new CalendarView()).toBeTruthy();
  });
});
